INTERSTICE
Diseñada por Clara Moll · @claramog.work
IED Madrid · Tutor: Diego Lara
Distribuida por ERRE ERRE FOUNDRY

CONTENIDO
  Fonts/OTF/   Archivos para instalar en tu ordenador (macOS, Windows, Linux).
  Fonts/Web/   Archivos WOFF2 para usar en páginas web con @font-face.
  LICENSE.txt  Condiciones de uso.

PESOS
  Thin · Regular · Bold · Sevra

INSTALACIÓN
  macOS:   doble clic en cada archivo .otf y pulsa "Instalar".
  Windows: clic derecho en cada archivo .otf y elige "Instalar".

USO EN WEB
  @font-face {
    font-family: "Interstice";
    src: url("Interstice-Regular.woff2") format("woff2");
    font-weight: 400;
  }

CARACTERES
  Minúsculas a–z, números 0–9, signos básicos, tildes (á é í ó ú), ñ
  y ligaduras (aj, ej, fj, ij, la, ll, ta, te…).

¿La has usado? Enséñanosla en la sección SUBMIT de la web.
